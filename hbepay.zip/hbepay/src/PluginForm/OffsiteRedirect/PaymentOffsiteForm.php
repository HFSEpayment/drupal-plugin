<?php

namespace Drupal\hbepay\PluginForm\OffsiteRedirect;

use Drupal\commerce_payment\PluginForm\PaymentOffsiteForm as BasePaymentOffsiteForm;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Render\Markup;

class PaymentOffsiteForm extends BasePaymentOffsiteForm {

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $form, FormStateInterface $form_state) {
    $form = parent::buildConfigurationForm($form, $form_state);

    $payment = $this->entity;
    $payment_gateway_plugin = $payment->getPaymentGateway()->getPlugin();
    $payment_configuration = $payment_gateway_plugin->getConfiguration();
    $order = $payment->getOrder();

    $test_url = "https://test-epay-oauth.epayment.kz/oauth2/token";
    $prod_url = "https://epay-oauth.homebank.kz/oauth2/token";
    $test_page = "https://test-epay.epayment.kz/payform/payment-api.js";
    $prod_page = "https://epay.homebank.kz/payform/payment-api.js";

    $hbp_description = $payment_configuration['Description'] ?: 'HB epay payment gateway';
    $hbp_env = $payment_configuration['mode'];
    $hbp_client_id = $payment_configuration['Client_id'];
    $hbp_client_secret = $payment_configuration['Client_secret'];
    $hbp_terminal = $payment_configuration['Terminal'];
    $hbp_invoice_id = '0800000' . $order->id();
    $hbp_amount = \Drupal::getContainer()->get('commerce_price.rounder')->round($payment->getAmount())->getNumber();
    $hbp_currency = $payment->getAmount()->getCurrencyCode();
    $hbp_back_link = $form['#return_url'];
    $hbp_failure_back_link = $form['#cancel_url'];

    $token_api_url = ($hbp_env === 'test') ? $test_url : $prod_url;
    $pay_page = ($hbp_env === 'test') ? $test_page : $prod_page;

    $fields = [
      'grant_type'      => 'client_credentials',
      'scope'           => 'payment usermanagement',
      'client_id'       => $hbp_client_id,
      'client_secret'   => $hbp_client_secret,
      'invoiceID'       => $hbp_invoice_id,
      'amount'          => $hbp_amount,
      'currency'        => $hbp_currency,
      'terminal'        => $hbp_terminal,
      'postLink'        => '',
      'failurePostLink' => '',
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $token_api_url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($fields));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($ch);
    $curl_error = curl_errno($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($curl_error || $http_code !== 200) {
      \Drupal::logger('hbepay')->error('cURL error: @error, HTTP code: @code, response: @response', [
        '@error' => curl_error($ch),
        '@code' => $http_code,
        '@response' => $result,
      ]);
      $form['hbepay_error'] = [
        '#markup' => $this->t('Не удалось подключиться к платёжному шлюзу. Ошибка: @err (код @code)', [
          '@err' => curl_error($ch) ?: $result,
          '@code' => $http_code,
        ]),
      ];
      return $form;
    }

    $hbp_auth = (object) json_decode($result, true);

    $hbp_payment_object = [
      "invoiceId" => $hbp_invoice_id,
      "backLink" => $hbp_back_link,
      "failureBackLink" => $hbp_failure_back_link,
      "postLink" => '',
      "failurePostLink" => '',
      "language" => 'EN',
      "description" => $hbp_description,
      "accountId" => '',
      "terminal" => $hbp_terminal,
      "amount" => $hbp_amount,
      "currency" => $hbp_currency,
      "auth" => $hbp_auth,
      "phone" => '',
      "email" => '',
    ];

    $form['#attached']['html_head'][] = [
      [
        '#tag' => 'script',
        '#attributes' => ['src' => $pay_page],
      ],
      'hbepay_widget_script',
    ];

    $form['hbepay_widget'] = [
      '#markup' => Markup::create(
        '<script>document.addEventListener("DOMContentLoaded", function() { halyk.pay(' . json_encode($hbp_payment_object) . '); });</script>'
      ),
    ];

    return $form;
  }

}
